/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tarea2;

/**
 *
 * @author Natalia
 */
public class mainTarea2 {

    public static void main(String[] args) {
        pedidosCliente informe = new pedidosCliente();
        int idCliente = 2;//Valor que se va a pasar para que lo recoja el parámetro
        informe.ejecutar(idCliente);
    }
}
