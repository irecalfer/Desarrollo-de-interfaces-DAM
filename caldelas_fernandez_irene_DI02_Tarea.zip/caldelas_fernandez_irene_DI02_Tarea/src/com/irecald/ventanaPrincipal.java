/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.irecald;

import Design.Ui_MainWindow;
import com.trolltech.qt.core.Qt;
import com.trolltech.qt.gui.QCheckBox;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QMainWindow;
import com.trolltech.qt.gui.QTableWidgetItem;
import com.trolltech.qt.gui.QWidget;
import java.util.ArrayList;

/**
 *
 * @author Irene Caldelas Fernandez
 */
public class ventanaPrincipal extends QMainWindow {

    private final Ui_MainWindow uiMain;
    private int columnas;
    private int filas;

    public ventanaPrincipal() {
        uiMain = new Ui_MainWindow();
        uiMain.setupUi(this);
        columnas = uiMain.lista.columnCount();
        uiMain.anadir.clicked.connect(this, "onBtnAgregarClicked()");
        uiMain.borrarTodo.clicked.connect(this, "borrarTodo()");
        uiMain.borrarSeleccion.clicked.connect(this, "borrarSeleccion()");
        uiMain.imprimir.clicked.connect(this, "imprimirLista()");
    }

    private void onBtnAgregarClicked() {
        //Asignamos a una variable el numero de filas que sacaremos segun
        //cuantos productos introduzcamos en la lista.
        filas = uiMain.lista.rowCount();

        //creamos un objeto de tipo anadeProductos el cual contiene toda la informacion
        //para añadir los productos a la lista de la compra
        anadeProductos uiDialogProducto = new anadeProductos(this, uiMain);

        if (uiDialogProducto.exec() == QDialog.DialogCode.Rejected.value()) {
            return;
        }

        //Añadimos una nueva fila cada vez que ingremos un producto
        uiMain.lista.insertRow(filas);
        //En la primera columna lo que vamos a hacer es añadir un checkbox que nos
        //permitira mas adelante seleccionar las filas que deseemos y pondremos 
        //el estado predefinido en Unchecked
        uiMain.lista.setCellWidget(filas, 0, uiMain.checkProducto = new QCheckBox());
        uiMain.checkProducto.setCheckState(Qt.CheckState.Unchecked);
        //En la columna 1 vamos a mostrar el dato del nombre del Producto.
        //En la columna 2 mostraremos la cantidad de ese producto siendo siempre
        //un numero positivo.
        //En la columna 3 veremos la seccion del super a la que pertenece el producto
        //En la fila 4 veremos si el producto es de compra urgente o no.
        uiMain.lista.setItem(filas, 1, new QTableWidgetItem(uiDialogProducto.getUiDialog().nomProd.text()));
        uiMain.lista.setItem(filas, 2, new QTableWidgetItem(String.valueOf(uiDialogProducto.getUiDialog().cantProd.value())));
        uiMain.lista.setItem(filas, 3, new QTableWidgetItem(uiDialogProducto.getUiDialog().seccion.currentText()));
        uiMain.lista.setItem(filas, 4, new QTableWidgetItem(uiDialogProducto.getUiDialog().urgente.currentText()));

    }

    public void imprimirLista() {
        //creamos un objeto de tipo Imprime en el cual imprimiremos la lista 
        Imprime imprimeListaCompra = new Imprime(this, uiMain);
        //ContieneDatosImpresion nos permitira almacenar la informacion
        //de cada producto para poder imprimirlas en modo texto.
        ArrayList<String> contieneDatosImpresion = new ArrayList<>();

        //Vamos a recorrer cada fila y cada columna de la lista de la compra.
        for (int i = 0; i < uiMain.lista.rowCount(); i++) {
            for (int j = 1; j < uiMain.lista.columnCount(); j++) {

                //Sacaremos cada dato de cada columna del producto y lo almacenaremos
                //en el arraylist
                contieneDatosImpresion.add(uiMain.lista.item(i, j).text());

            }

            //en el QtextBrowser iremos añadiendo cada producto con append para que 
            //no se sobrescriban unos a otros. Despoués de imprimir cada producto 
            //borraremos por completo el array y lo volveremos a rellenar.
            imprimeListaCompra.getUiDialogImprime().imprimeInformacion.append("Nombre:" + " " + contieneDatosImpresion.get(0)
                    + "\t" + "Cantidad:" + " " + contieneDatosImpresion.get(1) + "\t" + "Seccion:"
                    + "" + contieneDatosImpresion.get(2) + "\t" + "Urgente:"
                    + " " + contieneDatosImpresion.get(3) + "\n");

            contieneDatosImpresion.removeAll(contieneDatosImpresion);
        }

        if (imprimeListaCompra.exec() == QDialog.DialogCode.Rejected.value()) {
            return;
        }

    }

    public int getColumnas() {
        return columnas = uiMain.lista.columnCount();
    }

    public void borrarTodo() {
        //Al borrar todo tenemos en Ui_MainWindow una signal con selectAll y clear
        //que borrará el contenido de las filas. Posteriormente procederemos a borrar 
        //las filas. Reduciremos en uno cada vuelta del bucle para que no se salte
        //el siguiente indice al recolocarse tras el borrado.
        for (int i = 0; i < uiMain.lista.rowCount(); i++) {
            uiMain.lista.removeRow(i);
            i--;
        }

    }

    //Para borrar una seleccion de producto lo que haremos sera recorrer cada fila
    //de la lista de los productos y nos centraremos en sacar la primera celda
    //Comprobamos que lo que nos llega es de tipo checkbox y de ser asi casteamos el 
    //widget anterior a checkbox. Vemos si el estado es checked y de ser asi 
    //borramos la fila. Reducimos en uno el indice del bucle para que no suceda
    //lo mismo que en el caso de borraTodo
    public void borrarSeleccion() {
        QWidget item;
        for (int i = 0; i < uiMain.lista.rowCount(); i++) {
            item = uiMain.lista.cellWidget(i, 0);
            if (item instanceof QCheckBox) {
                QCheckBox checkBox = (QCheckBox) item;
                if (checkBox.checkState() == Qt.CheckState.Checked) {
                    uiMain.lista.removeRow(i);
                    i--;
                }
            }

        }
    }
}
