/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.irecald;

import Design.Ui_MainWindow;
import Design.Ui_Dialog_1;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QWidget;


/**
 *
 * @author Irene Caldelas Fernandez
 */
public class anadeProductos extends QDialog {

    private final Ui_Dialog_1 ui;
    private final Ui_MainWindow uiMain;

  
    public anadeProductos(QWidget parent, Ui_MainWindow uiMain) {
        super(parent);
        ui = new Ui_Dialog_1();
        ui.setupUi(this);
        this.uiMain = uiMain;
        //Si el usuario pulsa el boton de añadir, volvera a la ventana principal
        //habiendo añadido los datos de los productos a la lista.
        ui.anadeProducto.clicked.connect(this, "accept()");
        //En caso de dar atrás, no se efectuara ningun cambio.
        ui.atras.clicked.connect(this, "reject()");
        
        
    }

    
    //getUiDialog lo usaremos para poder acceder a los elementos de esa
    //ventana.
    public Ui_Dialog_1 getUiDialog(){
        return ui;
    }
    
 
    
    }


