/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.irecald;

import com.trolltech.qt.gui.QApplication;


/**
 *
 * @author Irene Caldelas Fernandez
 */
public class Inicio {
    
    public static void main (String[] args){
        QApplication.initialize(args);
        QApplication.setStyle("cleanlooks");
        
        ventanaPrincipal v = new ventanaPrincipal();
        v.show();
        
        
        
        QApplication.execStatic();
        QApplication.shutdown();
    }
    
}
