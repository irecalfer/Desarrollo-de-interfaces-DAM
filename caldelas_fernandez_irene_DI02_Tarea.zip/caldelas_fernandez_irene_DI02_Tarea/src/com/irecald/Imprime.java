/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.irecald;

import Design.Ui_MainWindow;
import Design.Ui_Dialog;
import com.trolltech.qt.gui.QDialog;
import com.trolltech.qt.gui.QTableWidgetItem;
import com.trolltech.qt.gui.QWidget;

/**
 *
 * @author Irene Caldelas Fernandez
 */
public class Imprime extends QDialog{
    private final Ui_Dialog ui;
    private final Ui_MainWindow uiMain;
    private QTableWidgetItem item;
    
    
    
    public Imprime(QWidget padre, Ui_MainWindow uiMain){
        super(padre);
        ui = new Ui_Dialog();
        ui.setupUi(this);
        this.uiMain = uiMain;
        //En caso de que pulsen el boton de atras, se volvera a la ventaqna principal
        ui.atrasImprime.clicked.connect(this, "reject()");
       
    }
    
    //getUiDialogImprime lo usaremos para poder acceder a los elementos de esa
    //ventana.
     public Ui_Dialog getUiDialogImprime(){
        return ui;
    }
     

         
}
