package Design;
/********************************************************************************
 ** Form generated from reading ui file 'dialogproducto.jui'
 **
 ** Created by: Qt User Interface Compiler version 4.8.6
 **
 ** WARNING! All changes made in this file will be lost when recompiling ui file!
 ********************************************************************************/



import com.trolltech.qt.core.*;
import com.trolltech.qt.gui.*;

public class Ui_Dialog_1 implements com.trolltech.qt.QUiForm<QDialog>
{
    public QFrame frame;
    public QHBoxLayout horizontalLayout;
    public QPushButton anadeProducto;
    public QPushButton atras;
    public QLabel label;
    public QWidget layoutWidget;
    public QGridLayout gridLayout;
    public QLabel label_2;
    public QLineEdit nomProd;
    public QLabel label_3;
    public QSpinBox cantProd;
    public QLabel label_4;
    public QLabel label_5;
    public QComboBox seccion;
    public QComboBox urgente;

    public Ui_Dialog_1() { super(); }

    public void setupUi(QDialog Dialog)
    {
        Dialog.setObjectName("Dialog");
        Dialog.resize(new QSize(400, 332).expandedTo(Dialog.minimumSizeHint()));
        frame = new QFrame(Dialog);
        frame.setObjectName("frame");
        frame.setGeometry(new QRect(10, 259, 381, 46));
        QSizePolicy sizePolicy = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Expanding);
        sizePolicy.setHorizontalStretch((byte)0);
        sizePolicy.setVerticalStretch((byte)0);
        sizePolicy.setHeightForWidth(frame.sizePolicy().hasHeightForWidth());
        frame.setSizePolicy(sizePolicy);
        frame.setFrameShape(com.trolltech.qt.gui.QFrame.Shape.StyledPanel);
        frame.setFrameShadow(com.trolltech.qt.gui.QFrame.Shadow.Raised);
        horizontalLayout = new QHBoxLayout(frame);
        horizontalLayout.setObjectName("horizontalLayout");
        anadeProducto = new QPushButton(frame);
        anadeProducto.setObjectName("anadeProducto");
        anadeProducto.setIcon(new QIcon(new QPixmap("classpath:com/trolltech/tools/designer/folder.png")));

        horizontalLayout.addWidget(anadeProducto);

        atras = new QPushButton(frame);
        atras.setObjectName("atras");

        horizontalLayout.addWidget(atras);

        label = new QLabel(Dialog);
        label.setObjectName("label");
        label.setGeometry(new QRect(130, 40, 139, 24));
        QFont font = new QFont();
        font.setFamily("Coming Soon");
        font.setPointSize(12);
        label.setFont(font);
        layoutWidget = new QWidget(Dialog);
        layoutWidget.setObjectName("layoutWidget");
        layoutWidget.setGeometry(new QRect(100, 90, 212, 116));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout.setObjectName("gridLayout");
        label_2 = new QLabel(layoutWidget);
        label_2.setObjectName("label_2");
        QFont font1 = new QFont();
        font1.setFamily("Arial");
        font1.setPointSize(11);
        label_2.setFont(font1);

        gridLayout.addWidget(label_2, 0, 0, 1, 1);

        nomProd = new QLineEdit(layoutWidget);
        nomProd.setObjectName("nomProd");

        gridLayout.addWidget(nomProd, 0, 1, 1, 2);

        label_3 = new QLabel(layoutWidget);
        label_3.setObjectName("label_3");
        QFont font2 = new QFont();
        font2.setFamily("Arial");
        font2.setPointSize(11);
        label_3.setFont(font2);

        gridLayout.addWidget(label_3, 1, 0, 1, 1);

        cantProd = new QSpinBox(layoutWidget);
        cantProd.setObjectName("cantProd");
        QSizePolicy sizePolicy1 = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Fixed);
        sizePolicy1.setHorizontalStretch((byte)0);
        sizePolicy1.setVerticalStretch((byte)0);
        sizePolicy1.setHeightForWidth(cantProd.sizePolicy().hasHeightForWidth());
        cantProd.setSizePolicy(sizePolicy1);
        cantProd.setButtonSymbols(com.trolltech.qt.gui.QAbstractSpinBox.ButtonSymbols.PlusMinus);
        cantProd.setMinimum(1);
        cantProd.setMaximum(999999);

        gridLayout.addWidget(cantProd, 1, 1, 1, 2);

        label_4 = new QLabel(layoutWidget);
        label_4.setObjectName("label_4");
        QFont font3 = new QFont();
        font3.setFamily("Arial");
        font3.setPointSize(11);
        label_4.setFont(font3);

        gridLayout.addWidget(label_4, 2, 0, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5.setObjectName("label_5");
        QFont font4 = new QFont();
        font4.setFamily("Arial");
        font4.setPointSize(11);
        label_5.setFont(font4);

        gridLayout.addWidget(label_5, 3, 0, 1, 2);

        seccion = new QComboBox(layoutWidget);
        seccion.setObjectName("seccion");

        gridLayout.addWidget(seccion, 2, 1, 1, 2);

        urgente = new QComboBox(layoutWidget);
        urgente.setObjectName("urgente");

        gridLayout.addWidget(urgente, 3, 2, 1, 1);

        retranslateUi(Dialog);

        Dialog.connectSlotsByName();
    } // setupUi

    void retranslateUi(QDialog Dialog)
    {
        Dialog.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Dialog", null));
        anadeProducto.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>A\u00f1ade el producto a la lista</p></body></html>", null));
        anadeProducto.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "A\u00f1adir", null));
        atras.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Vuelve a la lista sin realizar ning\u00fan cambio</p><p><br/></p></body></html>", null));
        atras.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Atr\u00e1s", null));
        label.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "A\u00f1adir un producto", null));
        label_2.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Nombre", null));
        nomProd.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Nombre del producto que se desea a\u00f1adir a la lista</p><p><br/></p></body></html>", null));
        nomProd.setInputMask("");
        label_3.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Cantidad", null));
        cantProd.setWhatsThis(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Cantidad de producto que se desea a\u00f1adir</p></body></html>", null));
        label_4.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Seccion super", null));
        label_5.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Producto urgente", null));
        seccion.clear();
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Panader\u00eda", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Carnicer\u00eda", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Charcuter\u00eda", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Conservas", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Permufer\u00eda", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "General", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Pescader\u00eda", null));
        seccion.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Fruter\u00eda", null));
        seccion.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Indica la seccion del supermercado a la que pertence el producto</p></body></html>", null));
        urgente.clear();
        urgente.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "S\u00ed", null));
        urgente.addItem(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "No", null));
        urgente.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Indica si la compra del producto es urgente o no</p></body></html>", null));
    } // retranslateUi

}

