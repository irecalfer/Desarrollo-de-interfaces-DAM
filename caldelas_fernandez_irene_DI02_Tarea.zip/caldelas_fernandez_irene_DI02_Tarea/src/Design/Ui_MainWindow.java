package Design;

/**
 * ******************************************************************************
 ** Form generated from reading ui file 'mainWindow.jui' * * Created by: Qt
 * User Interface Compiler version 4.8.6 * * WARNING! All changes made in this
 * file will be lost when recompiling ui file!
 *******************************************************************************
 */
import com.trolltech.qt.core.*;
import com.trolltech.qt.gui.*;

public class Ui_MainWindow implements com.trolltech.qt.QUiForm<QMainWindow> {

    public QWidget ventanaWidget;
    public QVBoxLayout verticalLayout;
    public QTableWidget lista;
    public QPushButton borrarTodo;
    public QPushButton borrarSeleccion;
    public QPushButton anadir;
    public QPushButton imprimir;
    public QCheckBox checkProducto;
    

    public Ui_MainWindow() {
        super();
    }

    public void setupUi(QMainWindow MainWindow) {
        MainWindow.setObjectName("MainWindow");
        MainWindow.resize(new QSize(539, 375).expandedTo(MainWindow.minimumSizeHint()));
        QSizePolicy sizePolicy = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Expanding);
        sizePolicy.setHorizontalStretch((byte) 0);
        sizePolicy.setVerticalStretch((byte) 0);
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth());
        MainWindow.setSizePolicy(sizePolicy);
        ventanaWidget = new QWidget(MainWindow);
        ventanaWidget.setObjectName("ventanaWidget");
        QSizePolicy sizePolicy1 = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Expanding);
        sizePolicy1.setHorizontalStretch((byte) 0);
        sizePolicy1.setVerticalStretch((byte) 0);
        sizePolicy1.setHeightForWidth(ventanaWidget.sizePolicy().hasHeightForWidth());
        ventanaWidget.setSizePolicy(sizePolicy1);
        ventanaWidget.setContextMenuPolicy(com.trolltech.qt.core.Qt.ContextMenuPolicy.ActionsContextMenu);
        verticalLayout = new QVBoxLayout(ventanaWidget);
        verticalLayout.setObjectName("verticalLayout");
        lista = new QTableWidget(ventanaWidget);
        lista.setObjectName("lista");
        lista.setFrameShape(com.trolltech.qt.gui.QFrame.Shape.Box);
        lista.setVerticalScrollBarPolicy(com.trolltech.qt.core.Qt.ScrollBarPolicy.ScrollBarAlwaysOn);
        lista.setHorizontalScrollBarPolicy(com.trolltech.qt.core.Qt.ScrollBarPolicy.ScrollBarAlwaysOff);
        lista.setEditTriggers(com.trolltech.qt.gui.QAbstractItemView.EditTrigger.createQFlags(com.trolltech.qt.gui.QAbstractItemView.EditTrigger.AnyKeyPressed, com.trolltech.qt.gui.QAbstractItemView.EditTrigger.EditKeyPressed, com.trolltech.qt.gui.QAbstractItemView.EditTrigger.SelectedClicked));
        lista.setAlternatingRowColors(true);
        lista.setSelectionMode(com.trolltech.qt.gui.QAbstractItemView.SelectionMode.MultiSelection);
        lista.setSelectionBehavior(com.trolltech.qt.gui.QAbstractItemView.SelectionBehavior.SelectRows);
        lista.setShowGrid(true);
        lista.setCornerButtonEnabled(true);
        lista.setRowCount(0);

        verticalLayout.addWidget(lista);

        borrarTodo = new QPushButton(ventanaWidget);
        borrarTodo.setObjectName("borrarTodo");

        verticalLayout.addWidget(borrarTodo);

        borrarSeleccion = new QPushButton(ventanaWidget);
        borrarSeleccion.setObjectName("borrarSeleccion");

        verticalLayout.addWidget(borrarSeleccion);

        anadir = new QPushButton(ventanaWidget);
        anadir.setObjectName("anadir");

        verticalLayout.addWidget(anadir);

        imprimir = new QPushButton(ventanaWidget);
        imprimir.setObjectName("imprimir");

        verticalLayout.addWidget(imprimir);

        MainWindow.setCentralWidget(ventanaWidget);
        retranslateUi(MainWindow);
        
        lista.clicked.connect(lista, "selectAll()");
        
        
        checkProducto = new QCheckBox();
        checkProducto.setObjectName("checkProducto");

        
        MainWindow.connectSlotsByName();
    } // setupUi

    void retranslateUi(QMainWindow MainWindow) {
        MainWindow.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "MainWindow", null));
        lista.clear();
        lista.setColumnCount(5);

        QTableWidgetItem __colItem = new QTableWidgetItem();
        __colItem.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Check", null));
        lista.setHorizontalHeaderItem(0, __colItem);

        QTableWidgetItem __colItem1 = new QTableWidgetItem();
        __colItem1.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Nombre", null));
        lista.setHorizontalHeaderItem(1, __colItem1);

        QTableWidgetItem __colItem2 = new QTableWidgetItem();
        __colItem2.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Cantidad", null));
        lista.setHorizontalHeaderItem(2, __colItem2);

        QTableWidgetItem __colItem3 = new QTableWidgetItem();
        __colItem3.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Secci\u00f3n", null));
        lista.setHorizontalHeaderItem(3, __colItem3);

        QTableWidgetItem __colItem4 = new QTableWidgetItem();
        __colItem4.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Urgente", null));
        lista.setHorizontalHeaderItem(4, __colItem4);
        lista.setRowCount(0);
        lista.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "<html><head/><body><p>Lista de los productos a\u00f1adidos</p><p><br/></p></body></html>", null));
        borrarTodo.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "<html><head/><body><p>Borra todos los rpoductos de la lista</p><p><br/></p></body></html>", null));
        borrarTodo.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Borrar Todo", null));
        borrarSeleccion.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "<html><head/><body><p>Borra los productos seleccionados</p><p><br/></p></body></html>", null));
        borrarSeleccion.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Borrar Selecci\u00f3n", null));
        anadir.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "<html><head/><body><p>A\u00f1ade un nuevo producto</p></body></html>", null));
        anadir.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "A\u00f1adir", null));
        imprimir.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "<html><head/><body><p>Genera una lista de la informaci\u00f3n acerca de la lista de la compra</p></body></html>", null));
        imprimir.setText(com.trolltech.qt.core.QCoreApplication.translate("MainWindow", "Imprimir", null));
    } // retranslateUi

}
