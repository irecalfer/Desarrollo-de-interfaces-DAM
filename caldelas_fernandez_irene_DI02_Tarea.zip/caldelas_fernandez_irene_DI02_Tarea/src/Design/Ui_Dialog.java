package Design;
/********************************************************************************
 ** Form generated from reading ui file 'imprimeinformacion.jui'
 **
 ** Created by: Qt User Interface Compiler version 4.8.6
 **
 ** WARNING! All changes made in this file will be lost when recompiling ui file!
 ********************************************************************************/


import com.trolltech.qt.core.*;
import com.trolltech.qt.gui.*;

public class Ui_Dialog implements com.trolltech.qt.QUiForm<QDialog>
{
    public QPushButton atrasImprime;
    public QTextBrowser imprimeInformacion;

    public Ui_Dialog() { super(); }

    public void setupUi(QDialog Dialog)
    {
        Dialog.setObjectName("Dialog");
        Dialog.resize(new QSize(400, 339).expandedTo(Dialog.minimumSizeHint()));
        QSizePolicy sizePolicy = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Expanding);
        sizePolicy.setHorizontalStretch((byte)0);
        sizePolicy.setVerticalStretch((byte)0);
        sizePolicy.setHeightForWidth(Dialog.sizePolicy().hasHeightForWidth());
        Dialog.setSizePolicy(sizePolicy);
        atrasImprime = new QPushButton(Dialog);
        atrasImprime.setObjectName("atrasImprime");
        atrasImprime.setGeometry(new QRect(10, 300, 381, 24));
        QSizePolicy sizePolicy1 = new QSizePolicy(com.trolltech.qt.gui.QSizePolicy.Policy.Expanding, com.trolltech.qt.gui.QSizePolicy.Policy.Fixed);
        sizePolicy1.setHorizontalStretch((byte)0);
        sizePolicy1.setVerticalStretch((byte)0);
        sizePolicy1.setHeightForWidth(atrasImprime.sizePolicy().hasHeightForWidth());
        atrasImprime.setSizePolicy(sizePolicy1);
        imprimeInformacion = new QTextBrowser(Dialog);
        imprimeInformacion.setObjectName("textBrowser");
        imprimeInformacion.setEnabled(true);
        imprimeInformacion.setGeometry(new QRect(10, 10, 381, 291));
        imprimeInformacion.setVerticalScrollBarPolicy(com.trolltech.qt.core.Qt.ScrollBarPolicy.ScrollBarAsNeeded);
        retranslateUi(Dialog);

        Dialog.connectSlotsByName();
    } // setupUi

    void retranslateUi(QDialog Dialog)
    {
        Dialog.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Dialog", null));
        atrasImprime.setToolTip(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "<html><head/><body><p>Vuelve a la lista</p></body></html>", null));
        atrasImprime.setText(com.trolltech.qt.core.QCoreApplication.translate("Dialog", "Atr\u00e1s", null));
    } // retranslateUi

}

